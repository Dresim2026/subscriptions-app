package com.dresim.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class LineStatus(val label: String) {
    ACTIVE("مفعّل"), SUSPENDED("معلّق"), DISCONNECTED("مفصول")
}
private data class SimLine(
    val id: Long,
    val number: String,
    val company: String,
    val distributor: String,
    val renewalDate: String,
    val status: LineStatus
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SimManagerApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SimManagerApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("sim_lines", 0) }
    var lines by remember {
        mutableStateOf(loadLines(prefs))
    }
    var search by remember { mutableStateOf("") }
    var showAdd by remember { mutableStateOf(false) }
    var filter by remember { mutableStateOf("الكل") }

    fun persist(updated: List<SimLine>) {
        lines = updated
        prefs.edit().putString("data", updated.joinToString("\n") {
            listOf(it.id, it.number, it.company, it.distributor, it.renewalDate, it.status.name)
                .joinToString("|")
        }).apply()
    }

    val visible = lines.filter {
        (search.isBlank() || it.number.contains(search) ||
                it.company.contains(search) || it.distributor.contains(search)) &&
                (filter == "الكل" || it.status.label == filter)
    }.sortedBy { when (it.status) {
        LineStatus.ACTIVE -> 0
        LineStatus.SUSPENDED -> 1
        LineStatus.DISCONNECTED -> 2
    } }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(title = {
                    Column {
                        Text("إدارة الخطوط", fontWeight = FontWeight.Bold)
                        Text("إدارة الشرائح والتجديدات", style = MaterialTheme.typography.labelMedium)
                    }
                })
            },
            floatingActionButton = {
                FloatingActionButton(onClick = { showAdd = true }) {
                    Text("+", style = MaterialTheme.typography.headlineMedium)
                }
            }
        ) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SummaryCard("الإجمالي", lines.size.toString(), Modifier.weight(1f))
                    SummaryCard("مفعّل", lines.count { it.status == LineStatus.ACTIVE }.toString(), Modifier.weight(1f))
                    SummaryCard("تنبيهات", lines.count { needsAlert(it.renewalDate) }.toString(), Modifier.weight(1f))
                }
                OutlinedTextField(
                    value = search, onValueChange = { search = it },
                    label = { Text("ابحث عن رقم أو شركة أو موزّع") },
                    modifier = Modifier.fillMaxWidth(), singleLine = true
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("الكل", "مفعّل", "معلّق", "مفصول").forEach { item ->
                        FilterChip(selected = filter == item, onClick = { filter = item },
                            label = { Text(item) })
                    }
                }
                if (visible.isEmpty()) {
                    Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                        Text(if (lines.isEmpty()) "لا توجد شرائح بعد. اضغط + لإضافة أول شريحة."
                             else "لا توجد نتائج مطابقة.")
                    }
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(visible, key = { it.id }) { line ->
                            Card(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(line.number, style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                        AssistChip(onClick = {}, label = { Text(line.status.label) })
                                    }
                                    Text("${line.company} • ${line.distributor}")
                                    Text("التجديد: ${line.renewalDate}")
                                    if (needsAlert(line.renewalDate)) {
                                        Text("تنبيه: موعد التجديد قريب أو متأخر",
                                            color = MaterialTheme.colorScheme.error)
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        TextButton(onClick = {
                                            val next = when (line.status) {
                                                LineStatus.ACTIVE -> LineStatus.SUSPENDED
                                                LineStatus.SUSPENDED -> LineStatus.DISCONNECTED
                                                LineStatus.DISCONNECTED -> LineStatus.ACTIVE
                                            }
                                            persist(lines.map { if (it.id == line.id) it.copy(status = next) else it })
                                        }) { Text("تغيير الحالة") }
                                        TextButton(onClick = { persist(lines.filterNot { it.id == line.id }) }) {
                                            Text("حذف")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showAdd) {
            AddLineDialog(
                onDismiss = { showAdd = false },
                onSave = { number, company, distributor, date, status ->
                    persist(lines + SimLine(System.currentTimeMillis(), number, company,
                        distributor, date, status))
                    showAdd = false
                }
            )
        }
    }
}

@Composable
private fun SummaryCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(title, style = MaterialTheme.typography.labelMedium)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddLineDialog(
    onDismiss: () -> Unit,
    onSave: (String, String, String, String, LineStatus) -> Unit
) {
    var number by remember { mutableStateOf("") }
    var company by remember { mutableStateOf("Cellcom") }
    var distributor by remember { mutableStateOf("") }
    var date by remember { mutableStateOf("") }
    var status by remember { mutableStateOf(LineStatus.ACTIVE) }
    var expanded by remember { mutableStateOf(false) }
    val companies = listOf("Cellcom", "Partner", "Pelephone", "HOT Mobile", "Golan", "019", "Wecom", "QuickLine", "Sky", "أخرى")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة شريحة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(number, { number = it }, label = { Text("رقم الشريحة") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), singleLine = true)
                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                    OutlinedTextField(company, {}, readOnly = true, label = { Text("الشركة") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        companies.forEach { item ->
                            DropdownMenuItem(text = { Text(item) }, onClick = {
                                company = item; expanded = false
                            })
                        }
                    }
                }
                OutlinedTextField(distributor, { distributor = it }, label = { Text("الموزّع") }, singleLine = true)
                OutlinedTextField(date, { date = it }, label = { Text("تاريخ التجديد (YYYY-MM-DD)") }, singleLine = true)
                Text("الحالة")
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    LineStatus.values().forEach { item ->
                        FilterChip(selected = status == item, onClick = { status = item },
                            label = { Text(item.label) })
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = number.isNotBlank() && date.isNotBlank(), onClick = {
                onSave(number.trim(), company, distributor.ifBlank { "—" }, date.trim(), status)
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

private fun loadLines(prefs: android.content.SharedPreferences): List<SimLine> {
    return prefs.getString("data", "").orEmpty().lineSequence().filter { it.isNotBlank() }.mapNotNull { row ->
        val p = row.split("|")
        if (p.size != 6) null else try {
            SimLine(p[0].toLong(), p[1], p[2], p[3], p[4], LineStatus.valueOf(p[5]))
        } catch (_: Exception) { null }
    }.toList()
}

private fun needsAlert(date: String): Boolean {
    return try {
        val parsed = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            .apply { isLenient = false }.parse(date) ?: return false
        val days = (parsed.time - System.currentTimeMillis()) / 86_400_000L
        days in 0..1 || days < 0
    } catch (_: Exception) { false }
}
